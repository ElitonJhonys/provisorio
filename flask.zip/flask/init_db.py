from app import create_app, db
from app.models import Usuario, Cliente, Veiculo, Locacao

app = create_app()

with app.app_context():
    # Cria todas as tabelas no banco de dados
    db.create_all()
    print("Tabelas criadas com sucesso!")
from flask import Blueprint, render_template, redirect, url_for, flash, abort
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models import Veiculo, Cliente, Locacao, Usuario
from app.forms import VeiculoForm, ClienteForm, LocacaoForm, LoginForm, CadastroUsuarioForm
from datetime import datetime
from functools import wraps

# Cria um Blueprint para as rotas
bp = Blueprint('main', __name__)

# Decorator para verificar se o usuário tem permissão
def permission_required(tipo_usuario):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.tipo == tipo_usuario:
                abort(403)  # Acesso proibido
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Rota Inicial
@bp.route('/')
def index():
    return render_template('index.html')

# Rotas para Veículos
@bp.route('/cadastrar_veiculo', methods=['GET', 'POST'])
@login_required
@permission_required('admin')  # Apenas admin pode cadastrar veículos
def cadastrar_veiculo():
    form = VeiculoForm()
    if form.validate_on_submit():
        veiculo = Veiculo(
            modelo=form.modelo.data,
            marca=form.marca.data,
            ano=form.ano.data,
            placa=form.placa.data,
            disponivel=form.disponivel.data
        )
        db.session.add(veiculo)
        db.session.commit()
        flash('Veículo cadastrado com sucesso!', 'success')
        return redirect(url_for('main.listar_veiculos'))
    return render_template('cadastrar_veiculo.html', form=form)

@bp.route('/veiculos')
@login_required
def listar_veiculos():
    veiculos = Veiculo.query.all()
    return render_template('listar_veiculos.html', veiculos=veiculos)

# Rotas para Clientes
@bp.route('/cadastrar_cliente', methods=['GET', 'POST'])
@login_required
@permission_required('funcionario')  # Apenas funcionário pode cadastrar clientes
def cadastrar_cliente():
    form = ClienteForm()
    if form.validate_on_submit():
        cliente = Cliente(
            nome=form.nome.data,
            cpf=form.cpf.data,
            email=form.email.data,
            telefone=form.telefone.data
        )
        db.session.add(cliente)
        db.session.commit()
        flash('Cliente cadastrado com sucesso!', 'success')
        return redirect(url_for('main.listar_clientes'))
    return render_template('cadastrar_cliente.html', form=form)

@bp.route('/clientes')
@login_required
def listar_clientes():
    clientes = Cliente.query.all()
    return render_template('listar_clientes.html', clientes=clientes)

# Rotas para Locações
@bp.route('/cadastrar_locacao', methods=['GET', 'POST'])
@login_required
@permission_required('funcionario')  # Apenas funcionário pode cadastrar locações
def cadastrar_locacao():
    form = LocacaoForm()
    if form.validate_on_submit():
        locacao = Locacao(
            cliente_id=form.cliente.data.id,
            veiculo_id=form.veiculo.data.id,
            data_inicio=form.data_inicio.data,
            data_fim=form.data_fim.data,
            valor_total=form.valor_total.data
        )
        # Marcar o veículo como indisponível
        veiculo = Veiculo.query.get(form.veiculo.data.id)
        veiculo.disponivel = False
        db.session.add(locacao)
        db.session.commit()
        flash('Locação cadastrada com sucesso!', 'success')
        return redirect(url_for('main.listar_locacoes'))
    return render_template('cadastrar_locacao.html', form=form)

@bp.route('/locacoes')
@login_required
def listar_locacoes():
    locacoes = Locacao.query.all()
    return render_template('listar_locacoes.html', locacoes=locacoes)

# Rotas para Autenticação
@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    form = LoginForm()
    if form.validate_on_submit():
        usuario = Usuario.query.filter_by(email=form.email.data).first()
        if usuario and usuario.check_senha(form.senha.data):
            login_user(usuario)
            flash('Login realizado com sucesso!', 'success')
            return redirect(url_for('main.index'))
        else:
            flash('Email ou senha incorretos.', 'danger')
    return render_template('login.html', form=form)

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logout realizado com sucesso!', 'success')
    return redirect(url_for('main.login'))

@bp.route('/cadastrar_usuario', methods=['GET', 'POST'])
@login_required
@permission_required('admin')  # Apenas admin pode cadastrar usuários
def cadastrar_usuario():
    form = CadastroUsuarioForm()
    if form.validate_on_submit():
        usuario = Usuario(
            nome=form.nome.data,
            email=form.email.data,
            tipo=form.tipo.data
        )
        usuario.set_senha(form.senha.data)
        db.session.add(usuario)
        db.session.commit()
        flash('Usuário cadastrado com sucesso!', 'success')
        return redirect(url_for('main.login'))
    return render_template('cadastrar_usuario.html', form=form)

# Manipulador de erro para acesso proibido (403)
@bp.errorhandler(403)
def acesso_proibido(error):
    return render_template('403.html'), 403
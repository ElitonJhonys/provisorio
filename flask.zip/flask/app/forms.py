from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, BooleanField, SubmitField, DateField, FloatField, PasswordField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo
from wtforms_sqlalchemy.fields import QuerySelectField
from app.models import Cliente, Veiculo

# Função para buscar clientes no banco de dados
def get_clientes():
    return Cliente.query.all()

# Função para buscar veículos disponíveis no banco de dados
def get_veiculos_disponiveis():
    return Veiculo.query.filter_by(disponivel=True).all()

# Formulário de Veículo
class VeiculoForm(FlaskForm):
    modelo = StringField('Modelo', validators=[DataRequired(), Length(max=100)])
    marca = StringField('Marca', validators=[DataRequired(), Length(max=100)])
    ano = IntegerField('Ano', validators=[DataRequired()])
    placa = StringField('Placa', validators=[DataRequired(), Length(max=10)])
    disponivel = BooleanField('Disponível', default=True)
    submit = SubmitField('Cadastrar Veículo')

# Formulário de Cliente
class ClienteForm(FlaskForm):
    nome = StringField('Nome', validators=[DataRequired(), Length(max=100)])
    cpf = StringField('CPF', validators=[DataRequired(), Length(min=11, max=14)])
    email = StringField('Email', validators=[DataRequired(), Length(max=100)])
    telefone = StringField('Telefone', validators=[DataRequired(), Length(max=15)])
    submit = SubmitField('Cadastrar Cliente')

# Formulário de Locação
class LocacaoForm(FlaskForm):
    cliente = QuerySelectField('Cliente', query_factory=get_clientes, get_label='nome', validators=[DataRequired()])
    veiculo = QuerySelectField('Veículo', query_factory=get_veiculos_disponiveis, get_label='modelo', validators=[DataRequired()])
    data_inicio = DateField('Data de Início', format='%Y-%m-%d', validators=[DataRequired()])
    data_fim = DateField('Data de Fim', format='%Y-%m-%d', validators=[DataRequired()])
    valor_total = FloatField('Valor Total', validators=[DataRequired()])
    submit = SubmitField('Cadastrar Locação')

# Formulário de Login
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    senha = PasswordField('Senha', validators=[DataRequired()])
    submit = SubmitField('Login')

# Formulário de Cadastro de Usuário
class CadastroUsuarioForm(FlaskForm):
    nome = StringField('Nome', validators=[DataRequired(), Length(max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    senha = PasswordField('Senha', validators=[DataRequired(), Length(min=6)])
    confirmar_senha = PasswordField('Confirmar Senha', validators=[DataRequired(), EqualTo('senha')])
    tipo = SelectField('Tipo de Usuário', choices=[('admin', 'Admin'), ('funcionario', 'Funcionário'), ('cliente', 'Cliente')], validators=[DataRequired()])
    submit = SubmitField('Cadastrar')